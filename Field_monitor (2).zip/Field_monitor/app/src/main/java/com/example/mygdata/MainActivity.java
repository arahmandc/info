package com.example.mygdata;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {


    ListView listView;
    SimpleAdapter adapter;
    ProgressDialog loading;
    EditText editTextSearchItem;

    TextView versionName;

//    ImageView imageView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Data List");

        listView = (ListView) findViewById(R.id.lv_items);

        listView.setOnItemClickListener(this);

        editTextSearchItem = (EditText)findViewById(R.id.et_search);

        getItems();

//        imageView = (ImageView)findViewById(R.id.iconImage);



        versionName = (TextView)findViewById(R.id.versionId);
        versionName.setText(BuildConfig.VERSION_NAME);


    }


    private void getItems() {

        loading =  ProgressDialog.show(this,"Loading","please wait",false,true);

//        App Scrept
//        https://script.google.com/macros/s/AKfycbwgHteJ4xr1vwL6VbNO8LO8vZIdS6qEf2CpVIHfTvmjQU3VhJw-/exec?action=getItems-->
//        Project version: 11

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://script.google.com/macros/s/AKfycbwgHteJ4xr1vwL6VbNO8LO8vZIdS6qEf2CpVIHfTvmjQU3VhJw-/exec?action=getItems",


                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);


    }


    private void parseItems(String jsonResposnce) {

        ArrayList<HashMap<String, String>> list = new ArrayList<>();

        try {
            JSONObject jobj = new JSONObject(jsonResposnce);
            JSONArray jarray = jobj.getJSONArray("sheet");
            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jo = jarray.getJSONObject(i);
                String sid = jo.getString("sid");
                String location_name = jo.getString("location_name");
                String category = jo.getString("category");
                String level = jo.getString("level");
                String lat = jo.getString("lat");
                String date = jo.getString("date");
                String longg = jo.getString("long");
                String image = jo.getString("image");


                HashMap<String, String> item = new HashMap<>();
                item.put("sid",sid);
                item.put("location_name",location_name);
                item.put("category", category);
                item.put("level", level);
                item.put("lat",lat);
                item.put("date",date);
                item.put("longg",longg);
                item.put("image",image);
                list.add(item);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        adapter = new SimpleAdapter(this,list,R.layout.list_item_rows,
                new String[]{"location_name","category","sid","level","lat","date","longg","image"},new int[]{R.id.tv_item_name,R.id.tv_brand});


        listView.setAdapter(adapter);
        loading.dismiss();

        editTextSearchItem.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                MainActivity.this.adapter.getFilter().filter(charSequence);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }

    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, ItemDetails.class);
        HashMap<String,String> map =(HashMap)parent.getItemAtPosition(position);
        String location_name = map.get("location_name").toString();
        String category = map.get("category").toString();
        String level = map.get("level").toString();
        String sid = map.get("sid").toString();
        String lat = map.get("lat").toString();
        String date = map.get("date").toString();
        String longg = map.get("longg").toString();
        String image = map.get("image").toString();


//        Picasso.get().load(image).into(imageView);



        // String sno = map.get("sno").toString();

        // Log.e("SNO test",sno);
        intent.putExtra("location_name",location_name);
        intent.putExtra("category",category);
        intent.putExtra("level",level);
        intent.putExtra("sid",sid);
        intent.putExtra("lat",lat);
        intent.putExtra("longg",longg);
        intent.putExtra("date",date);
        intent.putExtra("image",image);
        startActivity(intent);
    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

}