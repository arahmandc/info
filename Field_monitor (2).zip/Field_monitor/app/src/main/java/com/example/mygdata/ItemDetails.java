package com.example.mygdata;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class ItemDetails extends AppCompatActivity  {


    TextView textViewitemName, textViewCategory, textViewDetails,textViewDate;

    String location_name, category, level,image, sid,lat, longg, date;

    ImageView iv;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Details");

        setContentView(R.layout.item_detail);

        Intent intent = getIntent();
        location_name = intent.getStringExtra("location_name");
        category = intent.getStringExtra("category");
        level = intent.getStringExtra("level");
        sid = intent.getStringExtra("sid");
        lat = intent.getStringExtra("lat");
        longg = intent.getStringExtra("longg");
        date = intent.getStringExtra("date");
        image = intent.getStringExtra("image");


        textViewitemName = (TextView) findViewById(R.id.naMe_id);
        textViewCategory = (TextView) findViewById(R.id.categoryId);
        textViewDetails = (TextView) findViewById(R.id.detaiLs_id);
        textViewDate = (TextView) findViewById(R.id.dateId);
        iv = (ImageView)findViewById(R.id.imageViews);

        textViewitemName.setText(location_name);
        textViewCategory.setText(category);
        textViewDetails.setText(level);
        textViewDate.setText(date);


//        Note:
//         without google drive photo link "Image" option do no work.



        if(image==null){
            Picasso.get().load(R.drawable.ic_panorama_black_24dp).into(iv);
        }if(image!=null){
            Picasso.get().load(image).into(iv);
        }
    }
}