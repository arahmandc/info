package com.example.mygdata;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ListItem extends AppCompatActivity implements AdapterView.OnItemClickListener {


    ListView listView;
    SimpleAdapter adapter;
    ProgressDialog loading;
    EditText editTextSearchItem;

    ImageView imageView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_item);
        setTitle("View Data");

        listView = (ListView) findViewById(R.id.lv_items);

        listView.setOnItemClickListener(this);

        editTextSearchItem = (EditText)findViewById(R.id.et_search);

        getItems();

        imageView = (ImageView)findViewById(R.id.iconImage);


    }


    private void getItems() {

        loading =  ProgressDialog.show(this,"Loading","please wait",false,true);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://script.google.com/macros/s/AKfycbxS045a98q7vEGcN5hSaEieqHCd15nOE4SG7u0pM0jiVq_b0xTb/exec?action=getItems",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);


    }


    private void parseItems(String jsonResposnce) {

        ArrayList<HashMap<String, String>> list = new ArrayList<>();

        try {
            JSONObject jobj = new JSONObject(jsonResposnce);
            JSONArray jarray = jobj.getJSONArray("items");


            for (int i = 0; i < jarray.length(); i++) {

                JSONObject jo = jarray.getJSONObject(i);
                String sid = jo.getString("sid");
                String name = jo.getString("name");
                String age = jo.getString("age");
                String father = jo.getString("father");
                String address = jo.getString("address");
                String date = jo.getString("date");
                String mobile = jo.getString("mobile");
                String text = jo.getString("text");
                String mother = jo.getString("mother");
                String loca = jo.getString("loca");
                String image = jo.getString("image");


                HashMap<String, String> item = new HashMap<>();
                item.put("sid",sid);
                item.put("name",name);
                item.put("age", age);
                item.put("father", father);
                item.put("address",address);
                item.put("date",date);
                item.put("mobile",mobile);
                item.put("text",text);
                item.put("mother",mother);
                item.put("loca",loca);
                item.put("image",image);



                list.add(item);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

//        Log.e("uImage","ser image"+JsonParser.image[1]);

        adapter = new SimpleAdapter(this,list,R.layout.list_item_rows,
                new String[]{"sid","name","age","father","address","date","mobile","text","mother","loca","image"},new int[]{R.id.tv_price,R.id.tv_item_name,R.id.tv_brand});


        listView.setAdapter(adapter);
        loading.dismiss();

        editTextSearchItem.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                ListItem.this.adapter.getFilter().filter(charSequence);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }


    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, ItemDetails.class);
        HashMap<String,String> map =(HashMap)parent.getItemAtPosition(position);
        String name = map.get("name").toString();
        String age = map.get("age").toString();
        String father = map.get("father").toString();
        String sid = map.get("sid").toString();
        String mother = map.get("mother").toString();
        String date = map.get("date").toString();
        String address = map.get("address").toString();
        String text = map.get("text").toString();
        String loca = map.get("loca").toString();
        String mobile = map.get("mobile").toString();
        String image = map.get("image").toString();


//        Picasso.get().load(image).into(imageView);



        // String sno = map.get("sno").toString();

        // Log.e("SNO test",sno);
        intent.putExtra("name",name);
        intent.putExtra("age",age);
        intent.putExtra("father",father);
        intent.putExtra("sid",sid);
        intent.putExtra("mother",mother);
        intent.putExtra("address",address);
        intent.putExtra("mobile",mobile);
        intent.putExtra("text",text);
        intent.putExtra("date",date);
        intent.putExtra("loca",loca);
        intent.putExtra("image",image);


        startActivity(intent);
    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

}