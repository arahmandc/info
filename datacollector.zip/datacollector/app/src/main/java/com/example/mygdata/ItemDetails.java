package com.example.mygdata;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class ItemDetails extends AppCompatActivity  {


    TextView textViewitemName, textViewbrand, textViewprice,textViewId,textViewA,textViewB,textViewC,textViewD,textViewE,textViewF;
//    Button buttonUpdateItem, buttonDeleteItem;
    String sid, name, father, mother,date,age,address,mobile,text,loca,image;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Details");

        setContentView(R.layout.item_detail);

        Intent intent = getIntent();
        sid = intent.getStringExtra("sid");
        name = intent.getStringExtra("name");
        father = intent.getStringExtra("father");
        mother = intent.getStringExtra("mother");
        date = intent.getStringExtra("date");
        age = intent.getStringExtra("age");
        address = intent.getStringExtra("address");
        mobile = intent.getStringExtra("mobile");
        text = intent.getStringExtra("text");
        loca = intent.getStringExtra("loca");
        image = intent.getStringExtra("image");

        textViewId = (TextView)findViewById(R.id.tv_id);
        textViewitemName = (TextView) findViewById(R.id.tv_item_name);
        textViewbrand = (TextView) findViewById(R.id.tv_brand);
        textViewprice = (TextView) findViewById(R.id.tv_price);
        textViewA = (TextView) findViewById(R.id.tv_a);
        textViewB = (TextView) findViewById(R.id.tv_b);
        textViewC = (TextView) findViewById(R.id.tv_c);
        textViewD = (TextView) findViewById(R.id.tv_d);
        textViewE = (TextView) findViewById(R.id.tv_e);
        textViewF = (TextView) findViewById(R.id.tv_f);

        ImageView iv = (ImageView)findViewById(R.id.imageViews);



        textViewId.setText(sid);
        textViewitemName.setText(name);
        textViewbrand.setText(father);
        textViewprice.setText(mother);
        textViewA.setText(date);
        textViewB.setText(age);
        textViewC.setText(address);
        textViewD.setText(mobile);
        textViewE.setText(text);
        textViewF.setText(loca);


//        Picasso.get().load(image).into(iv);

        if(image==null){
            Picasso.get().load(R.drawable.ic_person_black_24dp).into(iv);
        }if(image!=null){
            Picasso.get().load(image).into(iv);
        }


    }
}