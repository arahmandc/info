package com.example.mygdata;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView versionName;
    Button buttonAddItem,buttonListItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        versionName = findViewById(R.id.app_version);
        buttonAddItem = (Button)findViewById(R.id.add_item);
        buttonListItem = (Button)findViewById(R.id.btn_list_items);

        versionName.setText("Version "+BuildConfig.VERSION_NAME);
        buttonAddItem.setOnClickListener(this);
        buttonListItem.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        if(v==buttonAddItem){
            Intent intent = new Intent(getApplicationContext(),Additem.class);
            startActivity(intent);
        }
        if(v==buttonListItem){

            Intent intent = new Intent(getApplicationContext(),ListItem.class);
            startActivity(intent);
        }

    }
}
