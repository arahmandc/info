package io.github.arahmandc.DataCollector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    public Button addButton;
    public TextView version;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        addButton = (Button)findViewById(R.id.addId);

        version =(TextView)findViewById(R.id.versionId);

        version.setText("Version :"+BuildConfig.VERSION_NAME);




        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Add_item.class);
                startActivity(intent);
            }
        });

    }

}