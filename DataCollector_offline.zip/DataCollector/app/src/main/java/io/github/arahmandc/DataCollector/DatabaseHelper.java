package io.github.arahmandc.DataCollector;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import static android.content.ContentValues.TAG;

public class DatabaseHelper extends SQLiteOpenHelper {


    private static final String DATABASE_NAME="Country.db";
    private static final String TABLE_NAME="Country_Details";
    private static final String ID="_id";
    private static final String LOCATION_NAME="Locetion_Name";
    private static final String CATEGORY="Category";
    private static final String LEVEL="Level";
    private static final String LAT="Lat";
    private static final String LON="Lon";
    private static final int VERSION_NUMBER=1;
    private static final String CREATE_TABLE="CREATE TABLE "+TABLE_NAME+"("+ID+" INTEGER PRIMARY KEY, "+LOCATION_NAME+" VARCHAR(100), "+CATEGORY+" VARCHAR(255),"+LEVEL+" VARCHAR(3000),"+LAT+" VARCHAR(50),"+LON+" VARCHAR(50) ) ;";

    private Context context;


    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION_NUMBER);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        try {
            sqLiteDatabase.execSQL(CREATE_TABLE);
            Toast.makeText(context, "On Create is called",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(context, "Exception: "+e,Toast.LENGTH_SHORT).show();
        }



    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        try {
            Toast.makeText(context, "On Upgrade is called",Toast.LENGTH_SHORT).show();

            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
//            sqLiteDatabase.execSQL(DROP_TABLE);
            onCreate(sqLiteDatabase);

        }catch (Exception e){
            Toast.makeText(context, "Exception: "+e,Toast.LENGTH_SHORT).show();
        }

    }

    public long saveData(String countryName,String category,String lavel,String lat,String lon){

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(LOCATION_NAME,countryName);
        contentValues.put(CATEGORY,category);
        contentValues.put(LEVEL,lavel);
        contentValues.put(LAT,lat);
        contentValues.put(LON,lon);
        long rowId = sqLiteDatabase.insert(TABLE_NAME,null,contentValues);
        return rowId;

    }

    public Cursor showData()
    {
        SQLiteDatabase sqLiteDatabase =this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM "+TABLE_NAME,null);
        return cursor;
    }

//    public DatabaseQueryClass(Context context){
//        this.context = context;
//        Logger.addLogAdapter(new AndroidLogAdapter());
//    }


    public boolean addData(String item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(LOCATION_NAME, item);

        Log.d(TAG, "addData: Adding " + item + " to " + TABLE_NAME);

        long result = db.insert(TABLE_NAME, null, contentValues);

        //if date as inserted incorrectly it will return -1
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Returns only the ID that matches the name passed in
     * @param countryName
     * @return
     */
    public Cursor getItemID(String countryName){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + ID + " FROM " + TABLE_NAME +
                " WHERE " + LOCATION_NAME + " = '" + countryName + "'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    /**
     * Updates the name field
     * @param newcountryName
     * @param id
     * @param oldcountryName
     */
    public void updateName(String newcountryName, int id, String oldcountryName){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + TABLE_NAME + " SET " + LOCATION_NAME +
                " = '" + newcountryName + "' WHERE " + ID + " = '" + id + "'" +
                " AND " + LOCATION_NAME + " = '" + oldcountryName + "'";
        db.execSQL(query);
    }

    /**
     * Delete from database
     * @param id
     * @param countryName
     */
    public void deleteName(int id, String countryName){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + TABLE_NAME + " WHERE "
                + ID + " = '" + id + "'" +
                " AND " + LOCATION_NAME + " = '" + countryName + "'";
        db.execSQL(query);
    }




}
