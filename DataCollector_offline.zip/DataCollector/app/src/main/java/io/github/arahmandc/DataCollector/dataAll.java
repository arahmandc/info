package io.github.arahmandc.DataCollector;

public class dataAll {


    private String id;
    private String countryName;
    private String category;
    private String level;
    private String lat;
    private String lon;

    public dataAll(String id, String countryName, String category, String level, String lat, String lon) {

        this.id=id;
        this.countryName=countryName;
        this.category=category;
        this.level=level;
        this.lat=lat;
        this.lon=lon;
    }

    public String getName() {
        return id;
    }

    public void setName(String id) {
        this.id = id;
    }






}
