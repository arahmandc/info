package io.github.arahmandc.DataCollector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

//    private static final String TAG = "DetailActivity";


    private TextView countryNameText;
//    private TextView countryNameText, categoryText, levelText,latText,lonText, idText;
//
//
//    String  countryName, category, level, lat, lon, id;

    String  countryName;


    DatabaseHelper DatabaseHelper;

//    private String selectedName;
//    private int selectedID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setTitle("Details");

//        idText=(TextView)findViewById(R.id.idText);
//        countryNameText=(TextView)findViewById(R.id.contrynameText);
//        categoryText=(TextView)findViewById(R.id.categoryText);
//        levelText=(TextView)findViewById(R.id.levelText);
//        latText=(TextView)findViewById(R.id.latText);
//        lonText=(TextView)findViewById(R.id.lonText);


//        DatabaseHelper = new DatabaseHelper(this);

        //get the intent extra from the ListDataActivity
//        Intent receivedIntent = getIntent();

//        //now get the itemID we passed as an extra
//        selectedID = receivedIntent.getIntExtra("id",-1); //NOTE: -1 is just the default value
//
//        //now get the name we passed as an extra
//        selectedName = receivedIntent.getStringExtra("countryName");


//        Intent intent = getIntent();
//        countryName=intent.getStringExtra("countryName");
//        category=intent.getStringExtra("category");
//        level=intent.getStringExtra("level");
//        lat=intent.getStringExtra("lat");
//        lon=intent.getStringExtra("lon");
//        id=intent.getStringExtra("id");
//
//
//        idText.setText(id);
//        countryNameText.setText(countryName);
//        categoryText.setText(category);
//        levelText.setText(level);
//        latText.setText(lat);
//        lonText.setText(lon);


    }
}
